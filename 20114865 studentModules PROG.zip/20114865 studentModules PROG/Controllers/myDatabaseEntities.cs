﻿namespace Webbb.Controllers
{
    internal class myDatabaseEntities
    {
        public myDatabaseEntities()
        {
        }
    }
}